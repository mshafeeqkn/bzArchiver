/*
 * hello.c
 *
 *  Created on: Feb 4, 2015
 *      Author: root
 */

#include "hello.h"

void setSourcePath(GtkWidget *widget, argWidgets *Widgets) {

	GtkWidget *dialog = gtk_file_chooser_dialog_new("Choose file", Widgets->window,
			GTK_FILE_CHOOSER_ACTION_OPEN, GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
			GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT, NULL);

	if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
		char *filename;

		filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
		gtk_entry_set_text(GTK_ENTRY(Widgets->tfSource), filename);
		g_free(filename);
	}

	gtk_widget_destroy(dialog);
}

void setDestPath(GtkWidget *widget, argWidgets *Widgets) {

	GtkWidget *dialog;

	dialog = gtk_file_chooser_dialog_new("Choose destination", Widgets->window,
			GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER, GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
			GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
			NULL);

	if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
		char *filename;

		filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
		gtk_entry_set_text(GTK_ENTRY(Widgets->tfDestination), filename);
		g_free(filename);
	}

	gtk_widget_destroy(dialog);
}

void entry_toggle_visibility(GtkWidget *checkbutton, argWidgets *Widgets) {

	if(!gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(Widgets->check)))
	{
		gtk_widget_set_sensitive(Widgets->btnDest, true);
	}
	else
	{
		gtk_entry_set_text(GTK_ENTRY(Widgets->tfDestination), "");
		gtk_widget_set_sensitive(Widgets->btnDest, false);
	}
}


void compressOrDecompress(GtkWindow *widget, argWidgets *Widgets)
{
	char *destination;
	char *source;
	const char *widgetString = gtk_entry_get_text(GTK_ENTRY(Widgets->tfSource));
	source = malloc(strlen(widgetString)+1);
	strcpy(source,widgetString);
	widgetString = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(Widgets->combo));

	if (!strcmp(widgetString, "Compress"))
	{
		widgetString = gtk_entry_get_text(GTK_ENTRY(Widgets->tfDestination));
		if(!strcmp(widgetString,""))
		{
			destination = malloc(strlen(source)+5);
			strcpy(destination,source);
			strcat(destination, ".bz2");
		}
		else
		{
			int destinationLength = strlen(widgetString)+strlen(getFileName(source))+6;		//('\0' ,".bz2",/)
			destination = malloc(destinationLength);
			strcpy(destination,widgetString);
			strcat(destination,"/");
			strcat(destination,getFileName(source));
			strcat(destination,".bz2");
		}
		compress(source, destination);

	}
	else if(!strcmp(widgetString, "Decompress"))
	{
		widgetString = gtk_entry_get_text(GTK_ENTRY(Widgets->tfDestination));
		if(!strcmp(widgetString,""))
		{
			destination = malloc(strlen(getPath(source))+strlen(removeLastExtension(getFileName(source)))+2);
			strcpy(destination, getPath(source));
			strcat(destination,"/");
			strcat(destination,removeLastExtension(getFileName(source)));
		}
		else
		{
			destination = malloc(strlen(widgetString)+strlen(removeLastExtension(getFileName(source)))+1);
			strcpy(destination,widgetString);
			strcat(destination,"/");
			strcat(destination, removeLastExtension(getFileName(source)));
		}
		decompress(source, destination);
	}

	free(source);
	free(destination);
}

